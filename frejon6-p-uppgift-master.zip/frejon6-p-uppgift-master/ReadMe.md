Om du kör windows:
byt ut width=1 till width=2 på rad 186 i den grafiska versionen för att få 
kvadratiska rutor i spelet.