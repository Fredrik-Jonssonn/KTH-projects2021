def stjarnsprak(inrad):
    utrad = ""
    for tkn in inrad:
        utrad += tkn
        utrad += '*'
    return utrad