while True:
    a = int(input("a?"))
    b = int(input("b?"))
    print("Kubsumman =", (a**3)+(b**3))


